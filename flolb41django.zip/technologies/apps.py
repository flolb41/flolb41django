from django.apps import AppConfig


class TechnologiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'technologies'
